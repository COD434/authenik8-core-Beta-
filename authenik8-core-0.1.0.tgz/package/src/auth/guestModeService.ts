export const Incognito = (req:Request, res:Response, next:NextFunction)=>{
const authHeader = req.headers.authorization;

        let token = authHeader?.split(" ")[1];
        let user = token? verifyToken(token) : null;

if(!user){
const GToken = guestToken();
user = verifyToken(GToken);
res.setHeader("X-Guest-Token",GToken);
guestCounter.inc({endpoint:req.path});

}
if(user?.type === "guest-mode"){
guestBlocked.inc({endpoint: req.path, method: req.method})
}
  (res as any).user = user;
  next();
}

